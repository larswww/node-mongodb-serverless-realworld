
adding the postman tests

removing the /api from the default postman env

creating the .env's and adding the dotenv plugin
actually... make a mistake, show how to get the log and all

(can save/set these in aws console if you prefer)

