module.exports = {
  globals: {
    baseURL: 'https://gqch1fr4jf.execute-api.us-east-1.amazonaws.com/dev/',
  }
}
